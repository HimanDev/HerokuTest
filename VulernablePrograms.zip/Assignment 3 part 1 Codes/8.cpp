#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int user_authentication(char *name,char *account,char *password) {
  char password_buffer[16];
  int auth_flag = 0;
  char name_buffer[16];
  char account_buffer[16];
  strcpy(name_buffer, password);
  strcpy(password_buffer, password);
  strcpy(account_buffer, account);
  if(strcmp(password_buffer, "hacking123") == 0)
    auth_flag = 1;
  if(strcmp(password_buffer, "hackdata123") == 0)
    auth_flag = 1;
  return auth_flag;
}


int main(int argc, char *argv[])
{
  char name_input[16];
  char password_input[16];
  char account_input[16];
  printf("Welcome to the ATM_management System\n");
  printf("Enter your Name\n");
  scanf ("%79s",name_input);
  printf("Enter your 10 digit Bank Account Number\n");
  scanf ("%79s",account_input);
  int len = strlen(account_input);
  if(len < 10){
    printf("Invalid Account Number\n");
  }else{
    printf("Please enter the password to login and recieve the ATM PIN\n");
    scanf ("%79s",password_input);
    if(user_authentication(name_input,account_input,password_input)) {
      printf("Login successful\n");
      printf("Your ATM PIN to withdraw cash is 1134");
    } else {
      printf("Login Failed.Try again with the correct password\n");
    }
  }
  return 1;
}
