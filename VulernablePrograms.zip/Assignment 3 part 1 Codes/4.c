#include<stdio.h>
//#include<conio.h>
#include<string.h>
//#include<cstdlib.h>
#define WINDOWS 1
//using namespace std;

void issued_books(){
   printf("\n1. [ID:1401] Hacking the Art of Exploitation 2nd Edition Jon Erickson.\n");
}
void withdraw_books(){
   printf("\n Book with ID: 1401 Successfully withdrawn.\n");
}

int main(){
   char pasword[16],usrname[10];
   int i,choice;
   int a,b;
   printf("Enter password: \n");
   gets(pasword);
 //  a = strcmp(usrname, userid);
   if(strcmp(pasword,"Not_So_Secure"))
   {
      printf("Access Denied!\n");
      return 1;
   }

   printf("Access Granted\n");

   printf("\n\t--------------------------------");
   printf("\n\t**************MENU**************");
   printf("\n\t1. LIST ISSUED BOOKS");
   printf("\n\t2. UN-ISSUE A BOOK");
   printf("\n\t3. EXIT");
   printf("\n\t--------------------------------");
   printf("\n\n");
   checkpoint:
      printf("\nEnter your choice: ");
      scanf("%d",&choice);
      if(choice ==1){
         issued_books();
         goto checkpoint;
      }
      else if(choice == 2){
         withdraw_books();
         goto checkpoint;
      }
      else{
         printf("\nGoing to Exit\n\n");
         return 0;
      }
}
