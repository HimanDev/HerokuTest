#include <stdio.h> 
#include <stdlib.h>
#include <string.h>  

//Main function

int main()
{
    FILE *fp, *ft; 
    char another;
    int choice;

    /* structure that represent student */
    struct stud
    {
        char name[20]; //name of student
        int age; // age of student
	float gpa; // grade of student
    };

    struct stud s; // variable for structure

    char studname[30]; // string to store name of the student

    long int recordsize; // size of each record of student

    fp = fopen("STUD.DAT","rb+");
    if(fp == NULL)
    {
        fp = fopen("STUD.DAT","wb+");
        if(fp == NULL)
        {
            printf("Connot open file");
            exit(1);
        }
    }

    recordsize = sizeof(s);

    LOOP:while(1)
    {
        printf("\n1. Add Record\n"); // add record
        printf("2. List Records\n"); //showing existing record
        printf("3. Modify Records\n"); //editing record
        printf("4. Delete Records\n"); //deleting record
        printf("5. Exit\n"); // exit from the program
        printf("Your Choice: "); 
        fflush(stdin); 
        scanf("%d", &choice); 
        {
	if(choice==1)
	{ 
            fseek(fp,0,SEEK_END); 
            another = 'y';  // y for YES
              // if user want to add another record
            do{
                printf("\nEnter name: ");
		scanf("%s", &studname);
                printf("\nEnter age: ");
                scanf("%d", &s.age);
                printf("\nEnter GPA: ");
                scanf("%f", &s.gpa);
		strcpy(s.name, studname);
	        fwrite(&s,recordsize,1,fp); // write the record in the file
	        printf("\nAdd another record(y/n) ");
                fflush(stdin);
                scanf("%s", &another);
            }while(another == 'y');
	    do{
		goto LOOP;
	}while(another == 'n');
       }
	else if(choice==2)
	{
            rewind(fp); 
            while(fread(&s,recordsize,1,fp)==1) 
            {
                printf("\n%s %d %.2f\n",s.name,s.age,s.gpa); // print the name, age and GPA
            }
            printf("\n");
		goto LOOP;
            return 2;
	}

       
	else if(choice==3)
	{
            another = 'y';
            while(another == 'y')
            {
                printf("Enter the student name to modify: ");
                scanf("%s", studname);
                rewind(fp);
                while(fread(&s,recordsize,1,fp)==1)  // fetch all record from file
                {
                    if(strcmp(s.name,studname) == 0)  //if entered name matches with one in file
                    {
                        printf("\nEnter new name,age and GPA: ");
                        scanf("%s%d%f",s.name,&s.age,&s.gpa);
                        fseek(fp,-recordsize,SEEK_CUR);
                        fwrite(&s,recordsize,1,fp); /// override the record
                        break;
                    }
                }
                printf("\nModify another record(y/n)");
                fflush(stdin);
                scanf("%s", &another);
		
            }
	goto LOOP;
            return 3; }
	else if(choice==4)
	{
            another = 'y';
            while(another == 'y')
            {
                printf("\nEnter name of student to delete: ");
                scanf("%s",studname);
                ft = fopen("Temp.dat","wb");  // create a intermediate file for temporary storage
                rewind(fp); // move record to starting of file
                while(fread(&s,recordsize,1,fp) == 1)  // read all records from file
                {
                    if(strcmp(s.name,studname) != 0)  // if the entered record match
                    {
                        fwrite(&s,recordsize,1,ft); 
                    }
                }
                fclose(fp);
                fclose(ft);
                remove("STUD.DAT"); 
                rename("Temp.dat","STUD.DAT"); 
                fp = fopen("STUD.DAT", "rb+");
                printf("Delete another record(y/n)");
                fflush(stdin);
                scanf("%s", &another);
            }
	goto LOOP;
           return 4; }
	else if (choice==5)
	
            fclose(fp);
            exit(0); 
        }
    }
    return 0;
}
