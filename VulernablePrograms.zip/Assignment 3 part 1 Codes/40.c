#include<stdio.h>
#include<string.h>
int bal = 100;
int withdraw(){
	int x=30;
    int a;
    printf("1.The Fault in Our Stars \n 2.Ready Player One \n 3.The Hunger Games \n 4.Exit\n ");
	printf("Enter the movie you want to rent\n");
	scanf("%d",&a);
	switch(a){
            case 1: printf("The remaining balance after rent of m1 is %d",bal-x);break;
            case 2: printf("The remaining balance after rent of m2 is %d",bal-x);break;
            case 3: printf("The remaining balance after rent of m3 is %d",bal-x);break;
            case 4: exit(0);break;
        }
	if(x>bal)
        {
		printf("Insufficient Balance\n");
	}
}

int deposit(){
	int x;
	printf("Enter the amount you want to deposit\n");
	scanf("%d",&x);
	bal = bal + x;
	printf("Your Transaction was successful amount was added to your account balance\n");
}

int main(void)
{
    int choice;
    int pass = 0;
    
    printf("\n Enter the password : \n");
    FILE *fp;
   int buff[8];
    char *p;
    
    p = gets (buff); 
    if (p == NULL) {
        printf("Password was NULL\n");
    } else {
        
        if(strcmp(buff, "thegeek"))
        {
            printf ("\n Wrong Password \n");
        }
        else
        {
            printf ("\n Correct Password \n");
            pass = 1;
        }
        
        if(pass)
        {
           	printf("1.Rent \n 2.Add Money \n 3.Remaining Balance \n 4.Exit\n Select a particular option");
		while(1){
		scanf("%d",&choice);
		switch(choice){
			case 1: withdraw();break;
			case 2: deposit();break;
			case 3: printf("The balance in your account is %d\n",bal);break;
			case 4: exit(0);break;
		}
	}
        }
        
        
        
        return 0;

    }
   
    
   
}
