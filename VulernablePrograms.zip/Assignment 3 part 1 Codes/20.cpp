using namespace std;
#include "cstring"
#include "iostream"
#include "fstream"
#include "cstdio"
#include "string"
const int MAX=20;
class Renter
{
	char RenterID[30],RenterName[30];
	string renterid[30],rentername[30];
	int nOfCars[5];
	char temp[30];
	int i,Users,sel;
	public:
	Renter()
	{
		i=1;
		Users=0;
	}
	void newRenter(int num)
	{
		std::ofstream fout;
		fout.open("Renter.xls",ios::app);
		for(int k=1;k<=num;k++)
		{
			cout<<"\nNEW Renter INFORMATION:";
			cout<<"\nEnter Renter id: ";
			gets(RenterID);
			renterid[i]=RenterID;
			fout<<"\n"<<renterid[i]<<"\t";
			cout<<"\nEnter Renter's name:";
			gets(RenterName);
			Users+=i; // It is assumed that the app also asks for payment of renter registration in multiples of cars being registered.
			cout<<"\n no: "<<renterid[i];
			strcpy(temp,RenterName);
			rentername[i]=RenterName;
			fout<<rentername[i]<<"\t";
			nOfCars[i]=0;

			i++;

			fout.close();
		}}
	void editRenter()
	{
		std::ofstream fout;
		fout.open("Renter.xls",ios::app);
		showRenter();
		cout<<"\nSelect to change: ";
		cin>>sel;
		cout<<"\n**NOTE:admission no will not be changed!!**";
		cout<<"\nModify Renter's name: ";
		gets(RenterName);
		rentername[i]=RenterName;
		fout<<rentername[sel];
		cout<<"\nNo. of Cars Renter issued: ";
		cin>>nOfCars[sel];
		fout<<nOfCars[sel];
		fout.close();
	}
	void showRenter()
	{
		std::ifstream fin;
		fin.open("Renter.xls");
		for(int j=1;j<=Users;j++)
		{
			fin>>renterid[j];
			fin>>rentername[j];
			fin>>nOfCars[j];
			cout<<"\n"<<renterid[j]<<"\t";
			cout<<"\t"<<rentername[j];
			cout<<"\t"<<nOfCars[j];
		}
		fin.close();
	}
};
class Car
{

	char vehicleID[20];
	int rent;
	int availableCars,i;
	char model[50];
	char owner[20];
	string VehicleID[MAX],location[MAX],Model[MAX],Owner[MAX];
	public:
		Car()
		{

			availableCars=0;
			i=1;
		}

		void newCar()
		{

			std::ofstream fin;
			fin.open("Car.xls",ios::app);
			cout<<"\nEnter Car details for renting:\n1.Car Vehicle ID( Registration Number):";
			cin>>vehicleID;
			VehicleID[i]=vehicleID;
			fin<<VehicleID[i]<<"\t";
			cout<<"\n2.Car Model:";
			gets(model);
			Model[i]=model;
        fin<<Model[i];
			fin<<"\t";
			cout<<"\n3.Owner Name:";
			gets(owner);
			Owner[i]=owner;
			fin<<Owner[i];
			location[i]="available";
			fin<<"\t";
			fin<<location[i];
			fin<<"\n";
			fin.close();
			availableCars+=i;
			i++;

		}

		void editCarDetails()
		{
			int select,sts;
			std::ifstream fin;
			std::ofstream fout;
			fin.open("Car.xls",ios::app);
			fout.open("Car.xls");
			showCars();
			cout<<"\nSelect which Car details to edit: ";
			cin>>select;
			cout<<"\nChange Car-id: ";
			cin>>vehicleID[select];
			fin>>vehicleID[select];
			cout<<"\nChange Model: ";
			std::getline(std::cin>>std::ws,Model[select]);
			fin>>Model[select];
			cout<<"\nChange Owner's name: ";
			std::getline(std::cin>>std::ws,Owner[select]);
			fin>>Owner[select];
			cout<<"\nlocation of Car?" ;
			cout<<"1.Available 2.Out Of Stock 3.Issued";
			cin>>sts;
			if(sts==1)
			location[select]="available";
			else if(sts==2)
			location[select]="OutOfStock";
			else if(sts==3)
			location[select]="Issued";
			else
			cout<<"\ninvalid choice";
			fin>>location[select];
			fin.close();
			fout.close();
		}

		void showCars()
		{
			ifstream fout;
			fout.open("Car.xls");
			for(int j=1;j<=availableCars;j++)
			{
				fout>>vehicleID[j];
				fout>>Model[j];
				fout>>Owner[j];
				fout>>location[j];

				cout<<"\n"<<vehicleID[j]<<"\t"<<Model[j];
				cout<<"\t"<<Owner[j]<<"\t"<<location[j];

			}
			cout<<"\n";
			fout.close();
		}

};



int main()
{
	int choice,ch,num;
	Car b;
	Renter s;
	ch=1;
	while(ch==1)
	{
		cout<<"\nSelect from the following options:";
		cout<<"\n1.NEW Car\n2.SHOW Car";
		cout<<"\n3.EDIT Car DETAILS";
		cout<<"\n4.NEW Renter ENTRY\n5.LIST ALL RenterS";
		cout<<"\n6.EDIT Renter DETAILS\n=>";
		cin>>choice;
		switch(choice)
		{
			case 1:{
				b.newCar();
				break;
				}


			case 2:{
				b.showCars();
				break;
				}

			case 3:{
				b.editCarDetails();
				break;
				}

			case 4:{
				cout<<"\nHow many Renters?";
				cin>>num;
				s.newRenter(num);
				break;
				}

			case 6:{
				s.editRenter();
				break;
			       }

			case 5:{
				s.showRenter();
				break;
			       }

			default:{
				cout<<"\nINVALID CHOICE";
				break;
				}
		}
	cout<<"\nwant to enter more?(1-yes, 0-no)";
	cin>>ch;
	}
}
