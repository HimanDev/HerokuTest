#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void openStudentPage()
{
	/*Iniitialization*/
	int gpa = 3;
	char studentName[16] = "StudentA";
	
	
	printf("Student Login\n");
	char userName[16];
	char userType[16];
    int authenticatedFlag = 1;
	char password[16];
	char command[16];
    
    printf("Enter account type (Student|Teacher)\n");
    scanf("%15s",&userType);
	printf("Enter UserName\n");
    scanf("%15s",&userName);
	printf("Enter Password\n");
    scanf("%15s",&password);
	
	if(strcmp (userName, "StudentA") == 0  && strcmp (password, "test") == 0  && strcmp(userType, "Student") == 0)
    {
 	   printf("Inside 1\n");
 	   authenticatedFlag = 0;
    }
    else if(strcmp (userName, "TeacherA") == 0  && strcmp (password, "test") == 0  && strcmp(userType, "Teacher")==0)
    {
 	   printf("Inside 2\n");
 	   authenticatedFlag = 0;
    }
	if(authenticatedFlag == 0)
	{
		while(1)
		{
			*command = 0;
			if (strcmp(userType, "Student")==0)
			{
				printf("\n\nStudent Portal\n");
				printf("Usage\n VIEW|QUIT\n");
				printf("Enter Command. Usage \n");
				scanf("%s",&command);
				if (strcmp(command,"QUIT")==0)
				{
					break;
				}
				else if (strcmp(command,"VIEW")==0)
				{
					printf("%s GPA %d\n",studentName,gpa);
				}
			}
			else if (strcmp(userType, "Teacher")==0)
			{
				printf("\n\nTeacher Portal\n");
				printf("Usage\nVIEW|QUIT|UPDATE\n");
				printf("Enter Command. Usage \n");
				scanf("%s",&command);
				if (strcmp(command,"QUIT")==0)
				{
					break;
				}
				else if (strcmp(command,"VIEW")==0)
				{
					printf("%s GPA %d\n",studentName,gpa);
				}
				else if (strcmp(command,"UPDATE")==0)
				{
					printf("Enter new Grade");
					scanf("%d",&gpa);
				}
			}
			else
			{
				printf("Unauthorized Access");
				break;
			}
		}
	}
	else
	{
		printf("Unauthorized access\n");
	}
}   
    
int main()
{
   printf("----------Student Grade Portal----------\n");
   openStudentPage();
}
