#include <iostream>
#include <vector>
#include <stdio.h>

using namespace std;

int delDir (vector <vector<string>> directory){
    //function only accessible through buffer overflow exploit
    string answer;
    cout << "Congratulations Access Granted!" << endl;
    cout << "Would you like to delete the directory? (Y/N) ";
    cin >> answer;
    if (answer == "Y") {
        directory.clear();
    }
    return 0;
}

int searchDir(vector <vector<string>> directory, int col, string input)
{
    bool found = false;
    for (int i = 0; i < directory.size(); i++){
        if (directory[i][col] == input){
            for (int j = 0; j < directory[i].size(); j++){
            cout << directory[i][j] << " ";
            found = true;
        }
        cout << endl;
        }
    }
    if (found == false && col == 0){
        cout << "Name Not Found." << endl;
    }
    else if (found == false && col == 1){
        cout << "Phone Number Not Found." << endl;
    }
    return 0;
}

int printDir(vector <vector<string>> directory)
{
    //print directory
    for (int i = 0; i < directory.size(); i++){
        for (int j = 0; j < directory[i].size(); j++){
            cout << directory[i][j] << " ";
        }
        cout << endl;
    }
    return 0;
}

int main()
{
    //initialize directory
    vector <vector<string>> directory{
        {"Thu Breazeale", "(749)-887-1573", "7206 Oakwood Drive Hopewell, VA 23860"},
        {"Priscila Mcbride", "(915)-341-1893", "9889 Gartner St. Hallandale, FL 33009"},
        {"Armand Runion", "(523)-805-3958", "628 Mayfair St. Streamwood, IL 60107"},
        {"Sheridan Weigand", "(534)-609-9553", "356 West Windfall Lane Portland, ME 04103"},
        {"Nicky Dunlap", "(208)-740-5021", "54 S. Bridge Drive Palos Verdes Peninsula, CA 90274"}
        };
    int choice = 0;
    string input = "";
    char buffer[30]; //buffer overflow exploit

    cout << "Enter Number to Choose Action: "<< endl
    << "1. Find Record Matching Name" << endl
    << "2. Find Record Matching Phone Number" << endl
    << "3. Print Directory" << endl;
    cin >> choice;

    switch(choice){
    case 1:
        cout << "Enter Name: ";
        cin.ignore();
        getline(cin, input);
        searchDir(directory, 0, input);
        break;
    case 2: //buffer overflow exploit
        cout << "Enter Phone Number: ";
        scanf("%s", buffer);
        input = buffer;
        searchDir(directory, 1, input);
        break;
    case 3:
        printDir(directory);
    }

    return 0;
}
