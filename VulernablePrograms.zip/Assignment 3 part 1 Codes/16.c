
#include<string.h>
#include<stdio.h>

char passwd[] = {'t','u','s','h','@','1','2','3','\0'};
char bankVaultCombination[] = {'3','6','5','8','2','1','8','4','6','7','0','2','9','\0'};

void showVaultPasswd();

int main()
{
	int userVerified=0;
	char userInputPasswd[15];	

	printf("Please enter your password to access the vault");
	printf("\n");

	scanf("%s", &userInputPasswd);
	
	if(strcmp(userInputPasswd,passwd))
	{
		printf("You are not authorized to access the bank vault");
		printf("\n");		
	}
	else
	{
		userVerified=1;
	}
	
	if(userVerified)
	{	
		showVaultPasswd();	
	}

	return 0;
}

void showVaultPasswd()
{
	printf("The bank vault combination is %s", bankVaultCombination);
	printf("\n");
}