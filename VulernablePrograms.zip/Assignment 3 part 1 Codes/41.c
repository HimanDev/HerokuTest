#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main() {
	srand(time(0));
	
	int tokens = 1;
	int continueGame = 1;
	char option[2];
	int bet = 0;
	
	printf("Coin Toss\n");
	printf("Start out with one token and guess the coin toss.\n");
	printf("Guess correctly and get double what you bet.\n");
	printf("Guess wrong and lose what you bet.\n");
	
	while (continueGame == 1) {
		printf("\nTokens: %d \n", tokens);
		
		invalidInput:
		printf("How many tokens do you want to bet: ");
		
		if (scanf("%d", &bet) == 0) {
			goto errorOccured;
		}
		
		if (bet > tokens) {
			printf("Not enough tokens to make that bet.\n");
			goto invalidInput;
		} else if (bet < 1) {
			printf("Bet one or more tokens.\n");
			goto invalidInput;
		}
		
		printf("Enter h for heads or t for tails: ");
		scanf("%s", &option);
		
		int outcomeNum = rand() % 2;
		char outcome[1];
		
		if (outcomeNum == 0) {
			outcome[0] = 'h';
		} else {
			outcome[0] = 't';
		}
		
		option[0] = tolower(option[0]);
		
		if (option[0] == outcome[0]) {
			tokens = tokens + (2 * bet);
			printf("Congrats! You guessed it right.\n");
		} else {
			tokens = tokens - bet;
			printf("Sorry! You guessed it wrong.\n");
		}
		
		printf("You now have %d token(s).\n", tokens);
		
		if (tokens < 1) {
			goto notEnough;
		}
		
		printf("Play again? enter 1 for yes or 0 for no: ");
		
		if (scanf("%d", &continueGame) == 0) {
			goto errorOccured;
		}
	}
	
	printf("Thanks for playing!\n");
	return 0;
	
	notEnough:
	printf("Not enough tokens to continue playing. Thanks for playing!\n");
	return 0;
	
	errorOccured:
	printf("An error occured.\n");
	return 1;
}
