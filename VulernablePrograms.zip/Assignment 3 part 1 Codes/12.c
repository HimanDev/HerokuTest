#include <stdio.h>
#include <stdlib.h>
#include <strings.h>
#define MAXBUF 15

int main()
{

    char creditInfo[MAXBUF];
    char name[MAXBUF];
    char address[MAXBUF];
    valid = 0;
    printf("Welcome to our Hotel Room RSVP System!\n");
    printf("To RSVP enter the following Information\nName: ");
    gets(name);
    printf("Address: ");
    gets(address);
    printf("Credit Card#: ");
    gets(creditInfo);
    valid = processCredit(creditInfo);
    if(valid ==1)
        printf("Thank you %s, you have RSVPED a room!\n\n\n",name);
    return 0;

}

int processCredit(char* c)
{
    int valid = 0;
    char credit[MAXBUF];
    strcpy(credit,c);
    printf("processing credit...\n");
    printf("Error processing credit. Please see or call staff to RSVP a room.\n\n\n");
    return valid;

}

