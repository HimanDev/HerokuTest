#include<stdio.h>
#include<conio.h>
#include<string.h>
struct acc_det
{
 char name[60];
 long int pin, acc_no, bal,balance,empid,emppass;
};
unsigned long balance= 0, account_no,pin_no,withdrawal;
int choice,choice1;
void main()
{
 int x,y,w,d,g;
 int emp_id,emp_pass;
 struct acc_det per1;
 struct acc_det per2;
 struct acc_det per3;
 struct acc_det emp;
 clrscr();
 emp.empid = 2145;
 emp.emppass = 2004;
 emp.balance = 200000;
 strcpy(per1.name,"Alex");
 per1.pin = 1234;
 per1.acc_no = 1;
 per1.bal = 2500;
 strcpy(per2.name,"John");
 per2.pin = 2345;
 per2.acc_no = 2;
 per2.bal = 12000;
 strcpy(per3.name,"James");
 per3.pin = 5643;
 per3.acc_no = 3;
 per3.bal = 1002;
 label:
 printf("\n************************************************************");
 printf("\n1.User login");
 printf("\n2.Admin login");
 printf("\n3.Exit");
 printf("\n************************************************************");
 printf("\nEnter your choice:");
 scanf("%d",&choice);
 switch(choice)
 {
  case 1: printf("\nEnter the Account Number:");
	  scanf("%d",&x);
	  if (x == per1.acc_no)
	  {
	   printf("\nEnter the Pin Number:");
	   scanf("%d",&y);
	   if(y == per1.pin)
	   {
	    printf("\nloggedin Successfully!!");
	    l:
	    printf("\n*******************************");
	    printf("\n1.Withdrawal");
	    printf("\n2.deposit");
	    printf("\n3.Balance checking");
	    printf("\n4.Logout");
	    printf("\n*******************************");
	    printf("\nEnter your choice:");
	    scanf("%d",&choice1);
	    switch(choice1)
	    {
	     case 1:printf("\nEnter the amount to be withdrawed:");
		    scanf("%d",&w);
		    if (w > per1.bal)
		    {
		     printf("\nOverdraft!!");
		     exit(0);
		    }
		    else
		    {
		     per1.bal = per1.bal - w;
		     emp.balance = emp.balance - w;
		    }
		    goto l;
	     case 2:printf("\nEnter the amount need to be deposited:");
		    scanf("%d",&d);
		    if(d == 0)
		    {
		     printf("invalid amount");
		    }
		    else
		    {
		     per1.bal = per1.bal + d;
		     emp.balance = emp.balance + d;
		    }
		    goto l;
	     case 3:printf("\n Current Balance is $ %d",per1.bal);
		    goto l;
	     case 4:goto label;
	    }
	   }else{printf("Invalid Pin Number Try Again!");}
	  }
	  else if(x == per2.acc_no)
	  {
	   printf("\nEnter the Pin Number:");
	   scanf("%d",&y);
	   if (y == per2.pin)
	   {
	    printf("\nloggedin Successfully!!");
	    l2:
	    printf("\n*******************************");
	    printf("\n1.Withdrawal");
	    printf("\n2.deposit");
	    printf("\n3.Balance checking");
	    printf("\n4.Logout");
	    printf("\n*******************************");
	    printf("\nEnter your choice:");
	    scanf("%d",&choice1);
	    switch(choice1)
	    {
	     case 1:printf("\nEnter the amount to be withdrawed:");
		    scanf("%d",&w);
		    if (w > per2.bal)
		    {
		     printf("\nOverdraft!!");
		     exit(0);
		    }
		    else
		    {
		     per2.bal = per2.bal - w;
		     emp.balance = emp.balance - w;
		    }
		    goto l2;
	     case 2:printf("\nEnter the amount need to be deposited:");
		    scanf("%d",&d);
		    if(d == 0)
		    {
		     printf("invalid amount");
		    }
		    else
		    {
		     per2.bal = per2.bal + d;
		     emp.balance = emp.balance + d;
		    }
		    goto l2;
	     case 3:printf("\n Current Balance is $ %d",per2.bal);
		    goto l2;
	     case 4:goto label;
	    }
	   }else{printf("Invalid Pin Number Try Again!");}
	  }
	  else if(x == per3.acc_no)
	  {
	   printf("\nEnter the Pin Number:");
	   scanf("%d",&y);
	   if(y == per3.pin)
	   {
	    printf("\nloggedin Successfully!!");
	    l3:
	    printf("\n*******************************");
	    printf("\n1.Withdrawal");
	    printf("\n2.deposit");
	    printf("\n3.Balance checking");
	    printf("\n4.Logout");
	    printf("\n*******************************");
	    printf("\nEnter your choice:");
	    scanf("%d",&choice1);
	    switch(choice1)
	    {
	     case 1:printf("\nEnter the amount to be withdrawed:");
		    scanf("%d",&w);
		    if (w > per3.bal)
		    {
		     printf("\nOverdraft!!");
		     exit(0);
		    }
		    else
		    {
		     per3.bal = per3.bal - w;
		     emp.balance = emp.balance - w;
		    }
		    goto l3;
	     case 2:printf("\nEnter the amount need to be deposited:");
		    scanf("%d",&d);
		    if(d == 0)
		    {
		     printf("invalid amount");
		    }
		    else
		    {
		     per3.bal = per3.bal + d;
		     emp.balance = emp.balance + d;
		    }
		    goto l3;
	     case 3:printf("\n Current Balance is $ %d ",per3.bal);
		    goto l3;
	     case 4:goto label;
	    }
	   }else{printf("Invalid Pin Number Try Again!");}
	  }
	  break;
  case 2:printf("\n Enter your ID:");
	 scanf("%d",&emp_id);
	 if(emp_id == emp.empid)
	 {
	  printf("\n Enter your Password:");
	  scanf("%d",&emp_pass);
	  if(emp_pass == emp.emppass)
	  {
	   set:
	   printf("\n*******************************************");
	   printf("\n1.Check amount in the ATM");
	   printf("\n2.Add currency to the ATM");
	   printf("\n3.Display any User Account Information");
	   printf("\n4.Logout");
	   printf("\n*******************************************");
	   printf("\n Enter your Choice:");
	   scanf("%d",&choice1);
	   switch(choice1)
	   {
	    case 1:printf("\nbalance = %d",emp.balance);
		   goto set;
	    case 2:printf("\nEnter the amount to be added:");
		   scanf("%d",&g);
		   emp.balance = emp.balance + g;
		   printf("$ %d Amount added successfully!",emp.balance);
		   goto set;
	    case 3:printf("\n#################################");
		   printf("\n           Details            ");
		   printf("\n PERSON-1");
		   printf("\n Name: %s",per1.name);
		   printf("\n Balance: %d",per1.bal);
		   printf("\n Account Number: %d",per1.acc_no);
		   printf("\n");
		   printf("\n PERSON-2");
		   printf("\n Name: %s",per2.name);
		   printf("\n Balance: %d",per2.bal);
		   printf("\n Account Number: %d",per2.acc_no);
		   printf("\n");
		   printf("\n PERSON-3");
		   printf("\n Name: %s",per3.name);
		   printf("\n Balance: %d",per3.bal);
		   printf("\n Account Number: %d",per3.acc_no);
		   printf("\n");
		   printf("\n#################################");
		   goto set;
	    case 4:goto label;
	   }
	  }else{printf("\nInvalid Password");}
	 }else{printf("\nInvalid ID");}
	 break;
  case 3:exit(0);
 }
 getch();
}
