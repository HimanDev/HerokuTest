#include <stdio.h>
#include <string.h>

int val(char *pwd){
	int key=0;
	char inp[5];
	
	strcpy(inp,pwd);
	
	if(strcmp(inp,"admin")==0)
		key=1;
	
	return key;
}

void acceptNo(char inp1[20]){
	if(val(inp1))
	{
		printf("\nWelcome Admin");
		printf("\n\nNext Lottery Details");
		printf("\n1)Date: 10/10/2018 - Lottery Winnning no: 23897");
		printf("\n1)Date: 10/20/2018 - Lottery Winnning no: 39871");
		printf("\n1)Date: 10/30/2018 - Lottery Winnning no: 45718");
		printf("\n1)Date: 11/10/2018 - Lottery Winnning no: 64827");
		printf("\n1)Date: 11/20/2018 - Lottery Winnning no: 98765\n");
		
	}	
	else{
		printf("\nwrong pass");
	}
}

void getlottery(){
	int no;
	int ch;
	//printf("\n\nPlease enter 5 digit number of your choice:");
	scanf("%d",&no);
	printf("\nyou entered : %d",no);
	printf("\n please press 1 to confirm and checkout:");
	scanf("%d",&ch);
	if(ch==1){
		printf("\nThank you for buying UTA Lottery");
		printf("\nYour booking is confirmed with the no: %d",no);
		printf("\n\nVisit Again!!\n");
	}
	else{
		printf("\n You cancelled your order.");
	}
}

int main(){
	int ch;
	char buf[20];
    printf("\n*****************************");
    printf("\nWelcome To UTA Lottery");
    printf("\n*****************************");
    printf("\n\nPlease select one option from below menu");
    printf("\nMenu:");
    printf("\n1 to Get the lottery number, Enter the lottery no upon selection");
    printf("\n2 to admin functionality and enter pasword");
    printf("\n3 to exit");
 	printf("\nEnter your choice:");
 	scanf("%d *[^\n]",&ch);
 	fflush(stdin);
 	if(ch==1){
 		getlottery();
 	}
 	else if(ch==2){
 		
 		//fseek(stdin,0,SEEK_END);
 		gets(buf);
 		printf("\nenter pass:%s",buf);
 		acceptNo(buf);
 	}
 	else if(ch==3){
 		return 0;
 	}	 
 	else{
		printf("\nyou entered invalid choice"); 	
	}	
    return 0;
}
