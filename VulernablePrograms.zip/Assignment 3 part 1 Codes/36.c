#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int log_in();
int is_only_valid_chars(char* str);
unsigned int  passwordHash(char* str, int length);
int getStrLen(char * str);
char get_menu_input();

struct user
{
	char* name;
	unsigned int password_hash;
	char* movie1;
	char* movie2;
	char* movie3;
};

struct user * user_data;
char username[15];

int main (void)
{
	user_data = (struct user *)malloc(sizeof(struct user));
	char* temp = "Adams42";
	user_data->name = (char *)malloc(sizeof(char)*getStrLen(temp));
	user_data->name = temp;
	user_data->password_hash = 156240100;	
	temp = "Avengers";
	user_data->movie1 = (char *)malloc(sizeof(char)*getStrLen(temp));
	user_data->movie1 = temp;
	temp = "Jurassic Park";
	user_data->movie2 = (char *)malloc(sizeof(char)*getStrLen(temp));
	user_data->movie2 = temp;
	temp = "Shrek";
	user_data->movie3 = (char *)malloc(sizeof(char)*getStrLen(temp));
	user_data->movie3 = temp;

	printf("\n***********************************************\n");
	printf("HINT: You know someone has the username Adams42\n");
	printf("***********************************************\n\n");

	int is_logged_in = log_in();
	char input = ' ';
	
	while (is_logged_in == -1) {
		printf("That login was incorrect, please try again.\n");
		is_logged_in = log_in();
	}

	printf("\n***************************\n");
	printf("Hello legitimate user!\n");
	printf("You logged in successfully!\n");
	printf("***************************\n");

	while (input != 'q') 
	{
		input = get_menu_input();

		if (input == 'o')
		{
			printf("Your movies:\n%s\n%s\n%s\n**************\n", user_data->movie1, user_data->movie2, user_data->movie3);
		}
		else if (input == 'b')
		{
			printf("Your friend the hacker will love this gift!\n");
			printf("$100 has been charged to your account.\n");
		}
		else if (input == 'd')
		{
			printf("Alright, Deleating account\nGoodby\n");
			free(user_data);
			input = 'q';
		}
		else if (input == 'q')
		{
			printf("Goodby\n");
		}
		else 
		{
			printf("That character was not an option. Please try again\n");
		}
	}
}

int log_in()
{
	char temp[15] = "              \0";
	*username = *temp;
	int is_correct = -1;
	char password[10];
	unsigned int hash;

	printf("Please enter your username: ");
	fgets(username, 14, stdin);
	if (username[0] == '\n') {
		fgets(username, 14, stdin);
	}
	username[14] = '\0';

	while ((is_only_valid_chars(username) == -1) || (strcmp(username, user_data->name) != 0)) {	//this is a nice function that validates the user's input
		if (strcmp(username, user_data->name) != 0) {
			printf("Could not find the username %s. Please try again.\n", username);
		}
		else {
			printf("Valid usernames are only made up of letters, numbers, and underscores.\n");
		}
		printf("Please enter your username: ");
		fgets(username, 14, stdin);
		username[14] = '\0';
	}	

	printf("%s, Please enter your password: ", username);
	scanf("%s", password);    
	hash = passwordHash(password, getStrLen(password)-1);
	
	if (hash == user_data->password_hash) {
		is_correct = 1;
	}
	
	return is_correct;
}

int is_only_valid_chars(char* str)	//see, we're secure, no way our system can be breached!
{
	char letter = str[0];
	int index = 0;
	while (letter != '\0') {
		if (letter == '\n') {
			letter = '\0';
			str[index] = '\0';
			return 1;
		}
		if ((letter != '_') && !(48 <= letter && letter <= 57)&& !(97 <= letter && letter <= 122) && !(65 <= letter && letter <= 90)) {
			return -1;
		}
		index++;
		letter = str[index];
	}
	return 1;
}

//Code from: http://www.partow.net/programming/hashfunctions/ from Robert Sedgwicks Algorithms in C book
//I know you shouldn't do this stuff yourself, but no one wants to install
//libraries to hash stuff when the homework is about buffer overflows
unsigned int  passwordHash(char* str, int length)
{
	unsigned int b = 378551;
	unsigned int a = 63689;
	unsigned int hash = 0;
	unsigned int i = 0;


	for (i = 0; i < length; ++str, ++i)
	{
		hash = hash * a + (*str);
		a = a * b;
	}
	//printf("%d", hash);

	return hash;
}

int getStrLen(char * str)
{
	int len = 0;
	int index = 0;
	char letter = str[0];

	while (letter != '\0') {
		len++;
		index++;
		letter = str[index];
	}
	return len+1;
}

char get_menu_input()
{
	char input;

	printf("\nHere's a menu of things that you can do:\n");
	printf("o - see movies you own\n");
	printf("b - buy a movie pass and gift it to a frient for $100\n");
	printf("d - delete account\n");
	printf("q - quit program\n");
	printf("***************************\n");
	scanf("%c", &input);
	scanf("%c", &input);
	return input;
}