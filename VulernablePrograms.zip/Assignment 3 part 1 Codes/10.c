#include<stdio.h>
#include<string.h>
#include<stdlib.h>
int students[4] = {0, 90, 80, 70};
void view_grades();
void login_portal();
void make_changes();
int main(){
int ans;
printf("Enter 1) For viewing grades. 2) For professor login \n");
scanf("%d", &ans);
	if(ans==1)
	{
		view_grades();
	}
	if(ans==2){
		login_portal();
	}
	else{
		printf("Wrong input");
	}
}

void view_grades(){
printf("3");
printf("\n1)Alan %d/100, 2)Josh %d/100, 3)Mick %d/100", students[1], students[2], students[3]);
}

void login_portal()
{
int flag =0;
char pass[]= "qwerty";
int password[6];
printf("\nEnter the password: ");
scanf("%s",&password);
if(strcmp(password, pass)==0){
	flag =1;
}
if(flag){
	make_changes();
}
else{
printf("wrong input");
}

}


void make_changes()
{
int ans, grade;
view_grades();
printf("\nEnter the number to make_changes: ");
scanf("%d", &ans);
if(ans>3 || ans<1){
printf("Wrong input");
exit(0);
}
printf("\nEnter the new grade: ");
scanf("%d", &grade);
printf("%d", ans);
students[ans]= grade;
view_grades();
}
