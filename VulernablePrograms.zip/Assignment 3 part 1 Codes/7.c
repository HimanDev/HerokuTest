#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int check_pin(char *pin){
	
	int verified =0;
	char pin_buff[9];

	strcpy(pin_buff, pin);
	if(strcmp(pin_buff,"6199")== 0)
		verified =1;	
	if(strcmp(pin_buff,"2542")== 0)
		verified =1;
	return verified;
}

int main(int argc, char *argv[]){
	int accBalance =0, amtDeposit;
	int anotherTransac =1;
	
	if(argc <2){
	printf("Please Enter a valid Pin.\n");
	exit(0);
}
if(check_pin(argv[1])){
printf("\n*****WELCOME TO XYZ BANK, YOU ARE VERIFIED*****\n");
while(anotherTransac ==1){
	int choice;
	
	printf("What would you like to do?: \n");
		printf("1 � Check Account Balance\n");
		printf("2 � Make Deposit\n");
		printf("3 � Withdraw Money\n");
		scanf("%d",&choice);
		if(choice ==1)
			{
				printf("Your account balance is: $%d \n", accBalance);
			}
		else if (choice ==2){
		printf("Enter the amount to deposit:");
		scanf("%d", &amtDeposit);
		if(amtDeposit>0){
		accBalance += amtDeposit;
		}else {
		printf("Invalid Deposit Amount\n");
		}
		}else if(choice==3){
		int amntWithdraw;
		printf("Enter the amount to withdraw:");
		scanf("%d", &amntWithdraw);
		if(amntWithdraw <= accBalance && amntWithdraw % 20 ==0){
		accBalance -= amntWithdraw;
		}else{
			if(amntWithdraw> accBalance){
				printf("Insufficient funds!!\n");
				}else {
						printf("Only Amount divisible by 20 is allowed\n ");
				}
		}
	}else{
		printf("Transaction Invalid.\n");
	}
	anotherTransac =0;
	while(anotherTransac !=1 && anotherTransac !=2){
	printf("Would you like to do another transaction:\n");
	printf("1: Yes, 2: No");
	scanf("%d",&anotherTransac);
	}
}
	return 0;
	}else {
	printf("\n Invalid Pin!!\n");
	return 0;
	}
}

