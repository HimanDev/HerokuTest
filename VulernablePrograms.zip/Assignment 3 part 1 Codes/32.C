#include <stdio.h>
#include <string.h>

struct Student
{
    char name[50];
    char subject[50];
    int marks;
};
struct Student studentArray[5];
void loadStudents()
{
    //load Himanshu data
    struct Student s1 = {"Himan", "Secure Programming", 100};
    struct Student s2 = {"Dave", "Secure Programming", 90};
    struct Student s3 = {"Riya", "Secure Programming", 89};
    struct Student s4 = {"Jack", "Secure Programming", 33};
    struct Student s5 = {"Danial", "Secure Programming", 44};

    studentArray[0] = s1;
    studentArray[1] = s2;
    studentArray[2] = s3;
    studentArray[3] = s4;
    studentArray[4] = s5;
}
void printStudent()
{
    for (int i = 0; i < sizeof(studentArray) / sizeof(studentArray[0]); i++)
    {
        printf("Name : %s\nSubject : %s\nMarks: %d\n", studentArray[i].name, studentArray[i].subject, studentArray[i].marks);
        printf("------------------------------------------------------------------\n");
    }
}
int main()
{
    char PASSWORD[5] = "1111";
    loadStudents();
    int check = 0;
    char inputPassword[5];
    printf("Please Enter Password to Access Students Resords\n");
    gets(inputPassword);
    if (strcmp(PASSWORD, inputPassword) == 0)
    {
        check = 1;
    }
    if (check)
    {
        printf("****Login Successful****\n Hello Professor \n");
        printStudent();
    }
    else
    {
        printf("Incorrect passwords\n");
    }
}