#include<stdio.h>
#include<string.h>
int main()
{
  char verify[8],moviename[10];
  printf("VERIFIED USER MOVIE ACCESS SYSTEM");
  printf("Enter the movie name you want to watch :\n");
  gets(moviename);
  printf("Enter the verifcation code for free movie access :");
  gets(verify);

  if(strcmp(verify,"verify03"))
  {
     printf("OH SORRY...YOUR CODE IS INVALID");
  }
  else
  {
   access();
  }


}

void access()
{
 printf("\nAccess granted\n");
 printf("CONGRATULATIONS YOU GET THE FREE MOVIE ACCESS");
 return;
}

