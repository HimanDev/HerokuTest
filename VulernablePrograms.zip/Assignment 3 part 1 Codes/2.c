#include<stdio.h>

int main(void) {
	printf("Welcome to the Payment Transfer system! \n"); 
	int auth=0;
	int fund;
	int uid;
	char storedpass[16]="pass123";
	char enteredpass[16];
	
pass:	printf("Enter your password:");
	scanf("%s",storedpass);

	if(strcmp(storedpass, enteredpass)==0)
	{
		auth=1;
	}
	
	if(auth)
	{
		printf("Authorization successful, Access Granted\n");
		printf("How much funds(in $) would you like to transfer?:");
		scanf("%d",&fund);
		printf("Enter the unique user id you want to transfer to:");
		
		scanf("%d",&uid);
		printf("$%d transfered to User ID:%d Transaction successful! \n",fund,uid);	 
	}
	else
	{
		printf("Incorrect password, please try again!\n");
		goto pass; 
	}
}
